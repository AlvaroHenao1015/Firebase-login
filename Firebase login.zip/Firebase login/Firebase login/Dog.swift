//
//  Dog.swift
//  Firebase login
//
//  Created by Alvaro Henao on 27/11/23.
//

import SwiftUI

struct Dog: Identifiable {
    var id: String
    var breed: String
}
